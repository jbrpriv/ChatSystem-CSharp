using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Text;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace Chat_Application
{

    public partial class Server : Form
    {
        IPAddress ip = IPAddress.Parse("172.20.10.6");
        List<OnlineUsers> online = new List<OnlineUsers>();
        List<OnlineUsers> clients = new List<OnlineUsers>();
        MySqlConnection conn = new MySqlConnection("server=127.0.0.2;uid=root;pwd=Sapphire7001;database=clients");
        MySqlCommand cmd;
        List<OnlineUsers> chatPair = new List<OnlineUsers>();
        public Server()
        {
            InitializeComponent();
        }



        public void setBusy(string S, string R)
        {
            try
            {
                conn.Open();
                string CommandText = "Update AvailableClients set availability= 'False' where user = '" + S + "';";
                cmd = new MySqlCommand(CommandText, this.conn);
                cmd.ExecuteNonQuery();
                cmd.CommandText = "Update AvailableClients set availability='False' where user = '" + R + "';";
                int rows = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                TcpListener mainConnection = new TcpListener(ip, 1);
                mainConnection.Start();
 
                TcpListener OnlineUsersConnecion = null;
                OnlineUsersConnecion = new TcpListener(ip, 2);
                OnlineUsersConnecion.Start();
    
                TcpListener invitationserver = new TcpListener(ip, 3);
                invitationserver.Start();

                TcpListener ConnectToClient = new TcpListener(ip, 4);
                ConnectToClient.Start();



                TcpListener chatListener = new TcpListener(ip, 5);
                chatListener.Start();


               
                Task.Run(() =>
                {
                    while (true)
                    {
                        TcpClient clientsignIN = mainConnection.AcceptTcpClient();
                        Task.Run(() => signIn(clientsignIN));



                    }
                });
                Task.Run(() =>
                {
                    while (true)
                    {

                        TcpClient clientOnlineUsers = OnlineUsersConnecion.AcceptTcpClient();
                        Task.Run(() => handleClient(clientOnlineUsers));


                    }
                });

                Task.Run(() =>
                {
                    while (true)
                    {
                        TcpClient clientsAvailable = invitationserver.AcceptTcpClient();
                        Task.Run(() =>
                        {
                            addClient(clientsAvailable);
                        });
                    }
                });

                Task.Run(() =>
                {
                    while (true)
                    {

                        TcpClient ConnectToTarget = ConnectToClient.AcceptTcpClient();
                        Task.Run(() => Connect(ConnectToTarget));
                    }
                });


                Task.Run(() =>
                {
                    while (true)
                    {
                        TcpClient chatclient = chatListener.AcceptTcpClient();
                        ConnectionInitialize(chatclient);
                    }
                });

                MessageBox.Show("All Server Started");
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void ConnectionInitialize(TcpClient c)
        {

            NetworkStream s = c.GetStream();
            byte[] buffer = new byte[1024];
            int bytesread = s.Read(buffer,0,buffer.Length);
            string msg  = Encoding.ASCII.GetString(buffer,0,bytesread);
            string[] data = msg.Split(":");
            OnlineUsers add = new OnlineUsers();
            add.setUser(data[1]);
            add.settcpClient(c);
            add.setNetworkStream(s);
            chatPair.Add(add);
            if (data[0].Equals("Join"))
            {
                foreach(OnlineUsers o  in chatPair)
                {
                    if (o.getUser().Equals(data[2]))
                    {
                        chatInitialize(s,o.GetNetworkStream());
                    }
                }
            }
        }
        public void chatInitialize(NetworkStream s, NetworkStream r)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = s.Read(buffer,0,buffer.Length);
                    r.Write(buffer,0,bytesRead);
                    
                }
            });

            Task.Run(() =>
            {
                while(true){
                    byte[] buffer = new byte[1024];
                    int bytesRead = r.Read(buffer, 0, buffer.Length);
                    s.Write(buffer,0,bytesRead);
                }
            });
        }
        public void Connect(TcpClient C)
        {

                byte[] buffer = new byte[1024];
                NetworkStream s = C.GetStream();
                int bytesRead = s.Read(buffer, 0, buffer.Length);
            if (bytesRead == 0)
            {
                MessageBox.Show("Client disconnected too early.");
                return;
            }
            string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                string[] segments = data.Split(":");

                if (segments[0].Equals("Connect"))

                {

                    foreach (OnlineUsers o in online)
                    {
                        if (o.getUser().Equals(segments[1]))
                        {
                            if (checkAvailability(o.getUser()))
                            {
                                
                                NetworkStream str = o.GetNetworkStream();
                                byte[] b = new byte[1024];
                                b = Encoding.ASCII.GetBytes("Invitation:" + segments[2]);
                                str.Write(b, 0, b.Length);
                                OnlineUsers cl = new OnlineUsers();
                                cl.settcpClient(C);
                                cl.setNetworkStream(s);
                                cl.setUser(segments[2]);
                                clients.Add(cl);
                            }
                            else
                            {
                                byte[] b = new byte[1024];
                                b = Encoding.ASCII.GetBytes("Client:Busy");
                                s.Write(b, 0, b.Length);

                            }
                        }
                    }
                }
            }
        
        
        public Boolean checkAvailability(string u)
        {
            conn.Open();
            cmd.CommandText = "Select * from AvailableClients;";
            MySqlDataReader r = cmd.ExecuteReader();
            while (r.Read()) 
            {
                if (r["user"].ToString() == u)
                {
                    if (r["availability"].ToString() == "True")
                    {
                        conn.Close();
                        return true;
                    }
                    
                }
            }
            conn.Close();
            return false;
        }
        public void addClient(TcpClient c)
        {
            while (true)
            {
                NetworkStream stream = c.GetStream();
                byte[] buffer = new byte[4096];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                string[] segments = data.Split(":");
                if (segments[0].Equals("Available"))
                {
                    conn.Open();
                    String Command = "Insert INTO AvailableClients(user,availability)Values('" + segments[1] + "'," + "'True');";
                    cmd = new MySqlCommand(Command, conn);
                    cmd.ExecuteNonQuery();
                    OnlineUsers users = new OnlineUsers();
                    users.setUser(segments[1]);
                    users.settcpClient(c);
                    users.setNetworkStream(stream);
                    online.Add(users);
                    conn.Close();
                }
                else if (segments[0].Equals("Confirmed"))
                {
                    foreach(OnlineUsers o in clients)
                    {
                        if (o.getUser().Equals(segments[2]))
                        {
                            buffer = new byte[4096];
                            buffer = Encoding.ASCII.GetBytes("Confirmed:" + segments[1]);
                            o.GetNetworkStream().Write(buffer, 0, buffer.Length);
                           
                            setBusy(segments[1], segments[2]);
                        }
                    }
                }
                else if (segments[0].Equals("Rejected"))
                {
                    foreach (OnlineUsers o in clients)
                    {
                        if (o.getUser().Equals(segments[2]))
                        {
                            buffer = new byte[4096];
                            buffer = Encoding.ASCII.GetBytes("Clients:" + "Busy");
                            o.GetNetworkStream().Write(buffer, 0, buffer.Length);

                        }
                    }
                }
                
            }
        }
        public void signIn(TcpClient client)
        {
            NetworkStream stream = null;
            byte[] buffer = new byte[1024];

                while (true)
                {
                    stream = client.GetStream();
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    string[] parts = data.Split(':');
                    if (parts[0] == "login")
                    {
                        string username = parts[1];
                        string pass = parts[2];
                       
                        String result = checkLoginInfo(username, pass).ToString();
                        buffer = Encoding.ASCII.GetBytes(result);
                        stream.Write(buffer, 0, buffer.Length);
                    
                }
                    else if(parts[0] =="signup")
                    {
                        string name = parts[1];
                        string username = parts[2];
                        string pass = parts[3];
                        String result =SignUp(name,username,pass).ToString();
                        buffer = Encoding.ASCII.GetBytes(result);
                        stream.Write(buffer, 0, buffer.Length);
                    }
                }
            

        }
        public Boolean SignUp(String Name,String Username,String pass)
        {
            Boolean check = checkLoginInfo(Username, pass);
            if (check) 
            {
                return false;
            }
            else
            {
                conn.Open();
                String Command = "Insert INTO userinfo(name,username,pass)Values('" + Name + "','" + Username + "','" + pass + "');";
                MySqlCommand cmd = new MySqlCommand(Command, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            
        }
        public Boolean checkLoginInfo(String Username,String Password)
        {
            MySqlConnection conn = new MySqlConnection();
            String ConnectionString = "server=127.0.0.2;uid=root;pwd=Sapphire7001;database=clients";
            conn.ConnectionString = ConnectionString;
            conn.Open();
            String Command = "select* from userinfo;";
            MySqlCommand cmd = new MySqlCommand(Command, conn);
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) 
            {
                if (reader["username"].ToString() == Username && reader["pass"].ToString() == Password)
                {
                    conn.Close();
                    return true;
                }
            }
            conn.Close();
            return false;
        }
        public void handleClient(TcpClient client)
        {
            NetworkStream stream = null;
            byte[] buffer = new byte[1024];
            Task.Run(() =>
            {
                while (true)
                {
                    stream = client.GetStream();
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    if (data == "online")
                    {
                        string builder = null;
                        foreach(OnlineUsers o in online)
                        {
                            builder += o.getUser() + ":";
                        }
                        
                        
                        byte[] response = new byte[1024];
                        response  = Encoding.ASCII.GetBytes(builder);
                        stream.Write(response, 0, response.Length);
                    }
                }
            });
        }

        public void sendInvitation(string targetUser, string SourceUser)
        {
            TcpClient targetClient = null;
            NetworkStream stream = null;
            foreach (OnlineUsers o in online)
            {
                if (o.getUser().Equals(targetUser))
                {
                    targetClient = o.gettcpClient();
                    byte[] buffer = new byte[1024];
                    stream = targetClient.GetStream();
                    buffer = Encoding.ASCII.GetBytes("Invitation:" + SourceUser);
                    stream.Write(buffer,0,buffer.Length);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection();
            String ConnectionString = "server=127.0.0.2;uid=root;pwd=Sapphire7001;database=clients";
            conn.ConnectionString = ConnectionString;
            conn.Open();
            String Command = "TRUNCATE AvailableClients;";
            MySqlCommand cmd = new MySqlCommand(Command, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            Close();
        }
    }
    public class OnlineUsers
    {
        TcpClient tcpClient;
        string User;
        NetworkStream str;

        public void setNetworkStream(NetworkStream s)
        {
            this.str = s;
        }
        public NetworkStream GetNetworkStream()
        {
            return this.str;
        }
        public void setUser(string User)
        {
            this.User = User;
        }
        public void settcpClient(TcpClient tcpClient)
        {
            this.tcpClient = tcpClient;
        }
        public TcpClient gettcpClient()
        {
            return this.tcpClient;
        }
        public string getUser()
        {
            return this.User;
        }
    }

}
