-- Create the database
CREATE DATABASE IF NOT EXISTS clients;
USE clients;

-- Table for user authentication (signup/login)
CREATE TABLE IF NOT EXISTS userinfo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    pass VARCHAR(255) NOT NULL
);

-- Table for tracking online users and their availability
CREATE TABLE IF NOT EXISTS AvailableClients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(50) NOT NULL,
    availability BOOLEAN NOT NULL DEFAULT TRUE
);