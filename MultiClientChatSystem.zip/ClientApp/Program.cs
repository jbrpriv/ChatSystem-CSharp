namespace ClientApp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Login login = new Login();
            if (login.ShowDialog() == DialogResult.OK) 
            {
                ChatGUI chatGUI = new ChatGUI(login.Username,login.ip);
                if (chatGUI.ShowDialog() == DialogResult.OK) {

                    MessageArea msgarea = new MessageArea();
                    msgarea.ip = chatGUI.ip;
                    msgarea.targetUser = chatGUI.targetuser;
                    msgarea.stream = chatGUI.chatStream;
                    msgarea.username = chatGUI.username;
                    msgarea.ShowDialog();
                
                }
               
            }
            
            
        }
    }
}