﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClientApp
{
    public partial class ChatGUI : Form
    {
        public string ip;
        public string username;
        TcpClient tcpClient;
        NetworkStream stream;
        public string targetuser;
        public NetworkStream chatStream;
        public ChatGUI(string u, string i)
        {

            InitializeComponent();
            user.Text = u;
            this.username = u;
            this.ip = i;

            Task.Run(() =>
            {
                setAvailable();
            });




        }
        public void setAvailable()
        {
            byte[] buffer = new byte[1024];
            tcpClient = new TcpClient(ip, 3);
            buffer = Encoding.ASCII.GetBytes("Available:" + this.username);
            stream = tcpClient.GetStream();
            stream.Write(buffer, 0, buffer.Length);

            while (true)
            {
                byte[] response = new byte[1024];
                int bytread = stream.Read(response, 0, response.Length);
                string res = Encoding.ASCII.GetString(response, 0, bytread);
                string[] msg = res.Split(":");
                this.Invoke(() =>
                {
                    DialogResult r = MessageBox.Show(res, "Accept?", MessageBoxButtons.YesNo);
                    if (r == DialogResult.Yes)
                    {
                        buffer = new byte[1024];
                        buffer = Encoding.ASCII.GetBytes("Confirmed:" + this.username + ":" + msg[1]);
                        stream.Write(buffer, 0, buffer.Length);
                        this.targetuser = msg[1];
                        InitializeRecieverConnection();
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }

                    else if (r == DialogResult.No)
                    {

                        buffer = new byte[1024];
                        buffer = Encoding.ASCII.GetBytes("Rejected:"+ this.username + ":" + msg[1]);
                        stream.Write(buffer, 0, buffer.Length);
                    }
                });




            }
        }
        public void InitializeRecieverConnection()
        {
            TcpClient C = new TcpClient(ip, 5);
            NetworkStream s = C.GetStream();
            byte[] buffer = new byte[1024];
            buffer = Encoding.ASCII.GetBytes("ReadyForChat:" + this.username);
            s.Write(buffer, 0, buffer.Length);
            this.chatStream = s;
        }
        public void showOnlineUsers()
        {
            OnlineBox1.Items.Clear();
            OnlineBox1.Items.Add("\t\t\t\tONLINE USERS");
            
            string onlineString = getOnlineUsers();

            string[] online = onlineString.Split(':');
            foreach (string s in online)
            {
                if (s != ":")
                {
                    OnlineBox1.Items.Add(s);
                }
            }
        }

        private void OnlineUsers_Click(object sender, EventArgs e)
        {
            onlinePanel.Visible = true;
            ConnectPanel.Visible = false;
            showOnlineUsers();
        }

        private void Connect_Click(object sender, EventArgs e)
        {
            if (OnlineBox1.SelectedItem != null)
            {
                if (this.username == OnlineBox1.SelectedItem.ToString())
                {
                    MessageBox.Show("Cannot Connect to Itself");
                }
                else
                {
                    byte[] buffer = new byte[1024];
                    buffer = Encoding.ASCII.GetBytes("Connect:" + OnlineBox1.SelectedItem.ToString() + ":" + this.username);
                    TcpClient c = new TcpClient(this.ip, 4);
                    NetworkStream cstream = c.GetStream();
                    cstream.Write(buffer, 0, buffer.Length);
                    MessageBox.Show("Invitation Sent");
                    Task.Run(() =>
                    {
                        while (true)
                        {
                            buffer = new byte[1024];
                            int bytesRead = cstream.Read(buffer, 0, 1024);
                            string msg = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                            string[] s = msg.Split(":");
                            if (s[0].Equals("Confirmed"))
                            {
                                this.Invoke(() => MessageBox.Show("Invitation Accepted"));
                                this.targetuser = s[1];
                                InitializeSenderConnection();
                                this.DialogResult = DialogResult.OK;
                                this.Invoke(() => this.Close());
                                break;

                            }
                            if (s[1].Equals("Busy"))
                            {
                                this.Invoke(() => MessageBox.Show("Client Busy"));
                                break;
                            }

                        }
                    });

                }
            }
            else
            {
                MessageBox.Show("Select A row");
            }
            //ConnectPanel.Visible = true;
            //onlinePanel.Visible = false;
        }

        private void Ex_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ChatGUI_Load(object sender, EventArgs e)
        {

        }


        public string getOnlineUsers()
        {

            TcpClient OnlineUsers = new TcpClient(this.ip, 2);
            NetworkStream OnlineUsersStream = OnlineUsers.GetStream();
            string Onlinedata = "online";
            byte[] buffer = Encoding.ASCII.GetBytes(Onlinedata);
            OnlineUsersStream.Write(buffer, 0, buffer.Length);
            byte[] responsebuffer = new byte[1024];
            int bytes = OnlineUsersStream.Read(responsebuffer, 0, responsebuffer.Length);
            string response = Encoding.ASCII.GetString(responsebuffer, 0, bytes);
            OnlineUsersStream.Close();
            return response;
        }

        private void ConnectButton_Click(object sender, EventArgs e)
        {
            
           
        }
        public void InitializeSenderConnection()
        {
            TcpClient c = new TcpClient(ip, 5);
            NetworkStream s = c.GetStream();
            byte[] buffer = new byte[1024];
            buffer = Encoding.ASCII.GetBytes("Join:" + this.username + ":" + this.targetuser);
            s.Write(buffer, 0, buffer.Length);
            this.chatStream = s;
        }
        private void ChatGUI_Load_1(object sender, EventArgs e)
        {

        }

        private void OnlineBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


