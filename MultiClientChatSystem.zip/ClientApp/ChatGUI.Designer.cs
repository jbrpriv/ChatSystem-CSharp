﻿namespace ClientApp
{
    partial class ChatGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OnlineUsers = new Button();
            Connect = new Button();
            Ex = new Button();
            user = new Label();
            ConnectPanel = new Panel();
            label1 = new Label();
            ConnectButton = new Button();
            userTextBox = new TextBox();
            onlinePanel = new Panel();
            OnlineBox1 = new ListBox();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            ConnectPanel.SuspendLayout();
            onlinePanel.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // OnlineUsers
            // 
            OnlineUsers.BackColor = Color.RoyalBlue;
            OnlineUsers.FlatStyle = FlatStyle.Popup;
            OnlineUsers.Font = new Font("Segoe UI", 11F);
            OnlineUsers.ForeColor = Color.White;
            OnlineUsers.Location = new Point(0, 151);
            OnlineUsers.Name = "OnlineUsers";
            OnlineUsers.Size = new Size(239, 75);
            OnlineUsers.TabIndex = 0;
            OnlineUsers.Text = "Online Users";
            OnlineUsers.UseVisualStyleBackColor = false;
            OnlineUsers.Click += OnlineUsers_Click;
            // 
            // Connect
            // 
            Connect.BackColor = Color.OliveDrab;
            Connect.FlatStyle = FlatStyle.Popup;
            Connect.Font = new Font("Segoe UI", 11F);
            Connect.ForeColor = Color.White;
            Connect.Location = new Point(0, 257);
            Connect.Name = "Connect";
            Connect.Size = new Size(239, 75);
            Connect.TabIndex = 1;
            Connect.Text = "Connect";
            Connect.UseVisualStyleBackColor = false;
            Connect.Click += Connect_Click;
            // 
            // Ex
            // 
            Ex.BackColor = Color.Firebrick;
            Ex.FlatStyle = FlatStyle.Popup;
            Ex.Font = new Font("Segoe UI", 11F);
            Ex.ForeColor = Color.White;
            Ex.Location = new Point(2, 367);
            Ex.Name = "Ex";
            Ex.Size = new Size(237, 75);
            Ex.TabIndex = 2;
            Ex.Text = "Exit";
            Ex.UseVisualStyleBackColor = false;
            Ex.Click += Ex_Click;
            // 
            // user
            // 
            user.AutoSize = true;
            user.Font = new Font("Segoe UI", 10F);
            user.ForeColor = Color.Black;
            user.Location = new Point(91, 49);
            user.Name = "user";
            user.Size = new Size(87, 23);
            user.TabIndex = 3;
            user.Text = "Username";
            // 
            // ConnectPanel
            // 
            ConnectPanel.Controls.Add(label2);
            ConnectPanel.Controls.Add(label1);
            ConnectPanel.Controls.Add(ConnectButton);
            ConnectPanel.Controls.Add(userTextBox);
            ConnectPanel.Location = new Point(261, 10);
            ConnectPanel.Name = "ConnectPanel";
            ConnectPanel.Size = new Size(759, 520);
            ConnectPanel.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F);
            label1.ForeColor = Color.OliveDrab;
            label1.Location = new Point(275, 20);
            label1.Name = "label1";
            label1.Size = new Size(220, 30);
            label1.TabIndex = 2;
            label1.Text = "Invite For Connection";
            // 
            // ConnectButton
            // 
            ConnectButton.BackColor = Color.OliveDrab;
            ConnectButton.FlatStyle = FlatStyle.Popup;
            ConnectButton.ForeColor = Color.White;
            ConnectButton.Location = new Point(410, 250);
            ConnectButton.Name = "ConnectButton";
            ConnectButton.Size = new Size(132, 32);
            ConnectButton.TabIndex = 1;
            ConnectButton.Text = "Connect";
            ConnectButton.UseVisualStyleBackColor = false;
            ConnectButton.Click += ConnectButton_Click;
            // 
            // userTextBox
            // 
            userTextBox.BackColor = Color.Lavender;
            userTextBox.Font = new Font("Segoe UI", 11F);
            userTextBox.Location = new Point(128, 250);
            userTextBox.Name = "userTextBox";
            userTextBox.Size = new Size(257, 32);
            userTextBox.TabIndex = 0;
            // 
            // onlinePanel
            // 
            onlinePanel.Controls.Add(OnlineBox1);
            onlinePanel.Location = new Point(261, 10);
            onlinePanel.Name = "onlinePanel";
            onlinePanel.Size = new Size(759, 520);
            onlinePanel.TabIndex = 5;
            // 
            // OnlineBox1
            // 
            OnlineBox1.BackColor = Color.Lavender;
            OnlineBox1.BorderStyle = BorderStyle.None;
            OnlineBox1.Font = new Font("Segoe UI", 10F);
            OnlineBox1.FormattingEnabled = true;
            OnlineBox1.ItemHeight = 23;
            OnlineBox1.Location = new Point(13, 20);
            OnlineBox1.Name = "OnlineBox1";
            OnlineBox1.Size = new Size(613, 414);
            OnlineBox1.TabIndex = 0;
            OnlineBox1.SelectedIndexChanged += OnlineBox1_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Lavender;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(OnlineUsers);
            panel1.Controls.Add(Connect);
            panel1.Controls.Add(Ex);
            panel1.Controls.Add(user);
            panel1.Location = new Point(-2, -1);
            panel1.Name = "panel1";
            panel1.Size = new Size(239, 569);
            panel1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.user;
            pictureBox1.InitialImage = Properties.Resources.user;
            pictureBox1.Location = new Point(10, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(65, 65);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(35, 255);
            label2.Name = "label2";
            label2.Size = new Size(87, 23);
            label2.TabIndex = 3;
            label2.Text = "Username";
            // 
            // ChatGUI
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lavender;
            ClientSize = new Size(1032, 561);
            Controls.Add(panel1);
            Controls.Add(onlinePanel);
            Controls.Add(ConnectPanel);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "ChatGUI";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Home";
            Load += ChatGUI_Load_1;
            ConnectPanel.ResumeLayout(false);
            ConnectPanel.PerformLayout();
            onlinePanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button OnlineUsers;
        private Button Connect;
        private Button Ex;
        private Label user;
        private Panel ConnectPanel;
        private Panel onlinePanel;
        private Panel panel1;
        private ListBox OnlineBox1;
        private Button ConnectButton;
        private TextBox userTextBox;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
    }
}