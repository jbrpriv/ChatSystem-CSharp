﻿namespace ClientApp
{
    partial class MessageArea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            UserName = new Label();
            chatArea = new ListBox();
            msgBox = new TextBox();
            sendButton = new Button();
            SuspendLayout();
            // 
            // UserName
            // 
            UserName.AutoSize = true;
            UserName.Font = new Font("Segoe UI", 11F);
            UserName.ForeColor = Color.OliveDrab;
            UserName.Location = new Point(250, 9);
            UserName.Name = "UserName";
            UserName.Size = new Size(63, 25);
            UserName.TabIndex = 0;
            UserName.Text = "label1";
            // 
            // chatArea
            // 
            chatArea.BackColor = Color.Lavender;
            chatArea.BorderStyle = BorderStyle.None;
            chatArea.Font = new Font("Segoe UI", 10F);
            chatArea.FormattingEnabled = true;
            chatArea.ItemHeight = 23;
            chatArea.Location = new Point(12, 37);
            chatArea.Name = "chatArea";
            chatArea.Size = new Size(562, 506);
            chatArea.TabIndex = 1;
            // 
            // msgBox
            // 
            msgBox.BackColor = Color.Lavender;
            msgBox.BorderStyle = BorderStyle.FixedSingle;
            msgBox.Font = new Font("Segoe UI", 11F);
            msgBox.Location = new Point(12, 597);
            msgBox.Name = "msgBox";
            msgBox.Size = new Size(445, 32);
            msgBox.TabIndex = 2;
            // 
            // sendButton
            // 
            sendButton.BackColor = Color.OliveDrab;
            sendButton.FlatStyle = FlatStyle.Popup;
            sendButton.Font = new Font("Segoe UI", 11F);
            sendButton.ForeColor = Color.White;
            sendButton.Location = new Point(463, 597);
            sendButton.Name = "sendButton";
            sendButton.Size = new Size(111, 32);
            sendButton.TabIndex = 3;
            sendButton.Text = "Send";
            sendButton.UseVisualStyleBackColor = false;
            sendButton.Click += sendButton_Click;
            // 
            // MessageArea
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lavender;
            ClientSize = new Size(586, 663);
            Controls.Add(sendButton);
            Controls.Add(msgBox);
            Controls.Add(chatArea);
            Controls.Add(UserName);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "MessageArea";
            StartPosition = FormStartPosition.CenterParent;
            Text = "MessageArea";
            Load += MessageArea_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label UserName;
        private ListBox chatArea;
        private TextBox msgBox;
        private Button sendButton;
    }
}