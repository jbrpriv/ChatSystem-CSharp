﻿namespace ClientApp
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            loginPanel = new Panel();
            pictureBox1 = new PictureBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            signUpPanel = new Panel();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            button4 = new Button();
            loginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            signUpPanel.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.OliveDrab;
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 38);
            button1.Name = "button1";
            button1.Size = new Size(236, 66);
            button1.TabIndex = 0;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.OliveDrab;
            button2.FlatStyle = FlatStyle.Popup;
            button2.ForeColor = Color.White;
            button2.Location = new Point(254, 38);
            button2.Name = "button2";
            button2.Size = new Size(270, 66);
            button2.TabIndex = 1;
            button2.Text = "Sign Up";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // loginPanel
            // 
            loginPanel.Controls.Add(pictureBox1);
            loginPanel.Controls.Add(textBox2);
            loginPanel.Controls.Add(textBox1);
            loginPanel.Controls.Add(label2);
            loginPanel.Controls.Add(label1);
            loginPanel.Location = new Point(66, 161);
            loginPanel.Name = "loginPanel";
            loginPanel.Size = new Size(395, 517);
            loginPanel.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_login_button_100;
            pictureBox1.Location = new Point(159, 259);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(83, 81);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.Lavender;
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Location = new Point(159, 172);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(168, 27);
            textBox2.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Lavender;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Location = new Point(159, 94);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(168, 27);
            textBox1.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(17, 174);
            label2.Name = "label2";
            label2.Size = new Size(91, 25);
            label2.TabIndex = 2;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.Location = new Point(17, 93);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 1;
            label1.Text = "Username";
            // 
            // signUpPanel
            // 
            signUpPanel.Controls.Add(textBox5);
            signUpPanel.Controls.Add(textBox4);
            signUpPanel.Controls.Add(textBox3);
            signUpPanel.Controls.Add(label5);
            signUpPanel.Controls.Add(label4);
            signUpPanel.Controls.Add(label3);
            signUpPanel.Controls.Add(button4);
            signUpPanel.Location = new Point(63, 161);
            signUpPanel.Name = "signUpPanel";
            signUpPanel.Size = new Size(398, 517);
            signUpPanel.TabIndex = 3;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.Lavender;
            textBox5.BorderStyle = BorderStyle.FixedSingle;
            textBox5.Location = new Point(162, 259);
            textBox5.Name = "textBox5";
            textBox5.PasswordChar = '*';
            textBox5.Size = new Size(154, 27);
            textBox5.TabIndex = 6;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.Lavender;
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Location = new Point(162, 176);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(154, 27);
            textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.Lavender;
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Location = new Point(162, 89);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(154, 27);
            textBox3.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(19, 258);
            label5.Name = "label5";
            label5.Size = new Size(91, 25);
            label5.TabIndex = 3;
            label5.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(14, 172);
            label4.Name = "label4";
            label4.Size = new Size(97, 25);
            label4.TabIndex = 2;
            label4.Text = "Username";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(40, 91);
            label3.Name = "label3";
            label3.Size = new Size(62, 25);
            label3.TabIndex = 1;
            label3.Text = "Name";
            // 
            // button4
            // 
            button4.BackColor = Color.RoyalBlue;
            button4.FlatStyle = FlatStyle.Popup;
            button4.ForeColor = Color.White;
            button4.Location = new Point(133, 425);
            button4.Name = "button4";
            button4.Size = new Size(136, 66);
            button4.TabIndex = 0;
            button4.Text = "Signup";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lavender;
            ClientSize = new Size(536, 706);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(loginPanel);
            Controls.Add(signUpPanel);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            loginPanel.ResumeLayout(false);
            loginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            signUpPanel.ResumeLayout(false);
            signUpPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Panel loginPanel;
        private Panel signUpPanel;
        private Button button4;
        private Label label2;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private PictureBox pictureBox1;
    }
}
