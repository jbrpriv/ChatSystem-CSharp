using System.Net.Sockets;
using System.Text;

namespace ClientApp
{
    public partial class Login : Form
    {
        TcpClient MainClient;
        NetworkStream Mainstream;
        public string ip = "172.20.10.6";
        public string Username;
        public Login()
        {
            InitializeComponent();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            loginPanel.BringToFront();
            signUpPanel.SendToBack();

        }


        private void button2_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            signUpPanel.BringToFront();
            loginPanel.SendToBack();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainClient = new TcpClient(ip, 1);
            Mainstream = MainClient.GetStream();
            string Name = textBox3.Text;
            string Username = textBox4.Text;
            string Pass = textBox5.Text;
            string data = "signup:" + Name + ":" + Username + ":" + Pass;
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            Mainstream.Write(buffer, 0, buffer.Length);
            Task.Run(() =>
            {

                byte[] responsebuffer = new byte[1024];
                int bytesRead = Mainstream.Read(responsebuffer, 0, responsebuffer.Length);
                string recieved = Encoding.ASCII.GetString(responsebuffer, 0, bytesRead);
                if (recieved == "True")
                {
                    MessageBox.Show("Signed Up");


                }
                else if (recieved == "False")
                {
                    MessageBox.Show("User Already Exists");
                    Mainstream.Close();
                }






            });

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MainClient = new TcpClient(ip, 1);
            Mainstream = MainClient.GetStream();
            Username = textBox1.Text;
            string Password = textBox2.Text;
            String data = "login:" + Username + ":" + Password;
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            Mainstream.Write(buffer, 0, buffer.Length);
            Task.Run(() =>
            {


                byte[] responsebuffer = new byte[1024];
                int bytesRead = Mainstream.Read(responsebuffer, 0, responsebuffer.Length);
                string recieved = Encoding.ASCII.GetString(responsebuffer, 0, bytesRead);
                this.Invoke(() =>
                {
                    if (recieved == "True")
                    {
                        MessageBox.Show("Signed IN");
                        Mainstream.Close();
                        this.DialogResult = DialogResult.OK;
                        Mainstream.Close();
                        this.Close();


                    }
                    else if (recieved == "False")
                    {
                        MessageBox.Show("Invalid CREDENTIALS");
                        Mainstream.Close();
                    }

                });
            });
        }
    }
}
