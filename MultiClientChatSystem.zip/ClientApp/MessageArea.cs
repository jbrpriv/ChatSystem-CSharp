﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.Devices;
using System.Net.Sockets;

namespace ClientApp
{
    public partial class MessageArea : Form
    {
        public string targetUser;
        public string username;
        public string ip;
        public NetworkStream stream;
        public MessageArea()
        {
            InitializeComponent();
            
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            string Sentmsg = msgBox.Text;
            byte[] buffer = new byte[8196];
            string sendmsg = this.username + ":" + Sentmsg;
            buffer = Encoding.ASCII.GetBytes(sendmsg);
            stream.Write(buffer, 0, buffer.Length);
            chatArea.Items.Add("You:" +Sentmsg);
            msgBox.Clear();
        }

        private void MessageArea_Load(object sender, EventArgs e)
        {
            UserName.Text = this.targetUser;

            Task.Run(() =>
            {
                while (true)
                {
                    byte[] response = new byte[8196];
                   int bytesRead = stream.Read(response,0,response.Length);
                    string msg = Encoding.ASCII.GetString(response,0,bytesRead);
                    this.Invoke(() => chatArea.Items.Add(msg));
                }
            });
        }

    }
    
}
